package ex04controlstatement;

public class Qu_04_01 {

	public static void main(String[] args) {

		
	}

}
